Single-link multi-file prototype. Share index.html only. Replace passwords in each level file if desired.
